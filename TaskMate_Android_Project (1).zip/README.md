# TaskMate Android App

A Java + XML Android Studio starter project based on the supplied TaskMate screenshots.

## Features
- Blue splash screen (`SplashActivity`) with TaskMate title and subtitle.
- Login screen (`LoginActivity`) using a vertical `LinearLayout`.
- Email and password input fields.
- Google sign-in button (Firebase Authentication setup required).
- Login button (basic input validation placeholder).
- Sign Up button opens a blank white screen (`SignUpActivity`).

## Important: Google sign-in setup
Google sign-in cannot authenticate until you connect this app to your own Firebase project.

1. Open https://console.firebase.google.com/ and create a Firebase project.
2. Add an Android app with package name `com.example.taskmate`.
3. Download `google-services.json` and put it in the `app/` folder.
4. In Firebase Authentication, enable **Google** as a sign-in provider.
5. Add your app's SHA-1 fingerprint in Firebase project settings. For local debug builds, Android Studio's Gradle signing report can show it.
6. Sync Gradle and run the app on a device with Google Play services.

The Google button opens the Google account chooser when configuration is valid. Without `google-services.json`, Firebase setup, and SHA-1 configuration, sign-in will not complete.

## Open in Android Studio
This ZIP contains the app source and Gradle configuration. Open the extracted folder in Android Studio, let Gradle sync, add `google-services.json`, and run it. Depending on your installed Android Gradle Plugin version, Android Studio may suggest updating Gradle/plugin versions.

## Project structure
- `app/src/main/java/com/example/taskmate/SplashActivity.java`
- `app/src/main/java/com/example/taskmate/LoginActivity.java`
- `app/src/main/java/com/example/taskmate/SignUpActivity.java`
- `app/src/main/res/layout/activity_splash.xml`
- `app/src/main/res/layout/activity_login.xml`
- `app/src/main/res/layout/activity_signup.xml`
- `app/src/main/AndroidManifest.xml`

## Layout note
The splash and login layouts use `LinearLayout`. The login layout uses `android:orientation="vertical"` so elements are arranged from top to bottom.
